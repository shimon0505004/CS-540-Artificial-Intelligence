import csv
import sys
import random
from collections import defaultdict

input_file_name = sys.argv[1]
output_file_name = sys.argv[2]


columns = defaultdict(list) # each value in each column is appended to a list

#with open(input_file_name) as f:
f = open(input_file_name)
reader = csv.DictReader(f) # read rows into a dictionary format
rowcounter = 0;
for row in reader: # read a row as {column1: value1, column2: value2,...}
    for (k,v) in row.items(): # go over each column name and value 
        columns[k].append(v) # append the value into the appropriate list
                             # based on column name k
        

                    
                                
            
                
        
        #outputFile.write(rowcounter
    rowcounter += 1
    
f.close() 
    #outputFile.write(range(0,rowcounter)
    #outputFile.write(rowcounter
outputFile = open(output_file_name,"wb")
for counter in range(0,rowcounter):
    displaySet = set()
        
        #J48 pruned tree
        #------------------
        #10-fold cross-validation
        #Correctly Classified Instances          12               23.0769 %
        #Incorrectly Classified Instances        40               76.9231 %
        #Kappa statistic                          0.113 
        #Mean absolute error                      0.1029
        #Root mean squared error                  0.2887
        #Relative absolute error                 91.4544 %
        #Root relative squared error            121.9409 %
        #Total Number of Instances               52     
        
    if(float(columns['aquamarine'][counter])) <= 254:
        if(float(columns['purple'][counter])) <= 41.3427:
            if(float(columns['almond'][counter])) <= 240.412135: 
                displaySet.add('duck')
            if(float(columns['almond'][counter])) > 240.412135:
                if(float(columns['almond'][counter])) <= 9475.205479:
                    if(float(columns['brown'][counter])) <= 0.671642: 
                        displaySet.add('falcon')
                    if(float(columns['brown'][counter])) > 0.671642:
                        if(float(columns['maroon'][counter])) <= 1.72: 
                            displaySet.add('parrot')
                        if(float(columns['maroon'][counter])) > 1.72:
                            if(float(columns['coral'][counter])) <= 0.7397: 
                                displaySet.add('chickadee')
                            if(float(columns['coral'][counter])) > 0.7397: 
                                displaySet.add('falcon')
                if(float(columns['almond'][counter])) > 9475.205479:
                    if(float(columns['almond'][counter])) <= 16956.39309: 
                        displaySet.add('sparrow')
                    if(float(columns['almond'][counter])) > 16956.39309: 
                        displaySet.add('chickadee')
        if(float(columns['purple'][counter])) > 41.3427:
            if(float(columns['coral'][counter])) <= 0.6464: 
                displaySet.add('goose')
            if(float(columns['coral'][counter])) > 0.6464:
                if(float(columns['gray'][counter])) <= 19: 
                    displaySet.add('sparrow')
                if(float(columns['gray'][counter])) > 19:
                    if(float(columns['green'][counter])) <= 2.636631: 
                        displaySet.add('chickadee')
                    if(float(columns['green'][counter])) > 2.636631: 
                        displaySet.add('petrel')
    if(float(columns['aquamarine'][counter])) > 254:
        if(float(columns['almond'][counter])) <= 3704.850222: 
            displaySet.add('robin')
        if(float(columns['almond'][counter])) > 3704.850222:
            if(float(columns['plum'][counter])) <= 9.92:
                if(float(columns['copper'][counter])) <= 10797: 
                    displaySet.add('goose')
                if(float(columns['copper'][counter])) > 10797: 
                    displaySet.add('albatross')
            if(float(columns['plum'][counter])) > 9.92: 
                displaySet.add('plover')
                    
                    
        #displaySet.add(',')           
                    
        #J48 pruned tree
        #Correctly Classified Instances          38               73.0769 %
        #Incorrectly Classified Instances        14               26.9231 %
        #Kappa statistic                          0.7077
        #Mean absolute error                      0.0399
        #Root mean squared error                  0.1412
        #Relative absolute error                 38.7046 %
        #Root relative squared error             62.3599 %
        #Total Number of Instances               52     
        
        
        #10fold cross validation shows that 2nd best is correct around 10% of the time. 
        #So 90% of the time we have to go for going for the third selection
        
    if(float(columns['brown'][counter])) <= 0.818182:
        if(float(columns['blue'][counter])) <= 0.8:
            if(float(columns['aqua'][counter])) <= 0.19:
                if(float(columns['seagreen'][counter])) <= 0.782908: 
                    displaySet.add('sparrow')
                if(float(columns['seagreen'][counter])) > 0.782908: 
                    displaySet.add('osprey')
            if(float(columns['aqua'][counter])) > 0.19:
                if(float(columns['violet'][counter])) <= 60.26: 
                    displaySet.add('falcon')
                if(float(columns['violet'][counter])) > 60.26: 
                    displaySet.add('roadrunner')
        if(float(columns['blue'][counter])) > 0.8:
            if(float(columns['copper'][counter])) <= 6165: 
                displaySet.add('plover')
            if(float(columns['copper'][counter])) > 6165: 
                displaySet.add('goose')
    if(float(columns['brown'][counter])) > 0.818182:
        if(float(columns['aqua'][counter])) <= 0.37:
            if(float(columns['indigo'][counter])) <= 0.461538:
                if(float(columns['aquamarine'][counter])) <= 267:
                    if(float(columns['almond'][counter])) <= 11242.06321: 
                        displaySet.add('robin')
                    if(float(columns['almond'][counter])) > 11242.06321: 
                        displaySet.add('plover')
                if(float(columns['aquamarine'][counter])) > 267:
                    if(float(columns['copper'][counter])) <= 24859: 
                        displaySet.add('swan')
                    if(float(columns['copper'][counter])) > 24859: 
                        displaySet.add('hummingbird')
            if(float(columns['indigo'][counter])) > 0.461538:
                if(float(columns['violet'][counter])) <= 19.22:
                    if(float(columns['aqua'][counter])) <= 0.06: 
                        displaySet.add('chickadee')
                    if(float(columns['aqua'][counter])) > 0.06: 
                        displaySet.add('puffin')
                if(float(columns['violet'][counter])) > 19.22:
                    if(float(columns['aquamarine'][counter])) <= 59:
                        if(float(columns['gray'][counter])) <= 348: 
                            displaySet.add('grouse')
                        if(float(columns['gray'][counter])) > 348: 
                            displaySet.add('swan')
                    if(float(columns['aquamarine'][counter])) > 59: 
                        displaySet.add('parrot')
        if(float(columns['aqua'][counter])) > 0.37:
            if(float(columns['black'][counter])) <= 0.467704: 
                displaySet.add('duck')
            if(float(columns['black'][counter])) > 0.467704: 
                displaySet.add('albatross')        
                    
        #displaySet.add(',')   
        
    
    
        #J48 pruned tree
        #------------------
        #Correctly Classified Instances          40               76.9231 %
        #Incorrectly Classified Instances        12               23.0769 %
        #Kappa statistic                          0.7514
        #Mean absolute error                      0.0285
        #Root mean squared error                  0.1193
        #Relative absolute error                 30.3612 %
        #Root relative squared error             55.1989 %
        #Total Number of Instances               52     

    if(float(columns['maroon'][counter])) <= 10.8:
        if(float(columns['lime'][counter])) <= 0.04202:
            if(float(columns['maroon'][counter])) <= 4.51:
                if(float(columns['purple'][counter])) <= 4.936: 
                    displaySet.add('swan')
                if(float(columns['purple'][counter])) > 4.936:
                    if(float(columns['aquamarine'][counter])) <= 57:
                        if(float(columns['aquamarine'][counter])) <= 29:
                            if(float(columns['blue'][counter])) <= 0.492903: 
                                displaySet.add('chickadee')
                            if(float(columns['blue'][counter])) > 0.492903: 
                                displaySet.add('bluejay')
                        if(float(columns['aquamarine'][counter])) > 29:
                            if(float(columns['aqua'][counter])) <= 0.13: 
                                displaySet.add('sparrow')
                            if(float(columns['aqua'][counter])) > 0.13: 
                                displaySet.add('falcon')
                    if(float(columns['aquamarine'][counter])) > 57: 
                        displaySet.add('chickadee')
            if(float(columns['maroon'][counter])) > 4.51:
                if(float(columns['green'][counter])) <= 0.685812:
                    if(float(columns['brown'][counter])) <= 0.833333: 
                        displaySet.add('parrot')
                    if(float(columns['brown'][counter])) > 0.833333:
                        if(float(columns['maroon'][counter])) <= 6.38: 
                            displaySet.add('duck')
                        if(float(columns['maroon'][counter])) > 6.38: 
                            displaySet.add('parrot')
                if(float(columns['green'][counter])) > 0.685812: 
                    displaySet.add('roadrunner')
        if(float(columns['lime'][counter])) > 0.04202:
            if(float(columns['orange'][counter])) <= 0.998336: 
                displaySet.add('egret')
            if(float(columns['orange'][counter])) > 0.998336:
                if(float(columns['gold'][counter])) <= 0.42: 
                    displaySet.add('puffin')
                if(float(columns['gold'][counter])) > 0.42: 
                    displaySet.add('osprey')
    if(float(columns['maroon'][counter])) > 10.8:
        if(float(columns['plum'][counter])) <= 8.44:
            if(float(columns['almond'][counter])) <= 809.061489: 
                displaySet.add('pigeon')
            if(float(columns['almond'][counter])) > 809.061489: 
                displaySet.add('plover')
        if(float(columns['plum'][counter])) > 8.44:
            if(float(columns['black'][counter])) <= 0.504526:
                if(float(columns['beige'][counter])) <= 204002:
                    if(float(columns['seagreen'][counter])) <= 0.7:
                        if(float(columns['red'][counter])) <= 0.04: 
                            displaySet.add('grouse')
                        if(float(columns['red'][counter])) > 0.04: 
                            displaySet.add('swan')
                    if(float(columns['seagreen'][counter])) > 0.7: 
                        displaySet.add('egret')
                if(float(columns['beige'][counter])) > 204002: 
                    displaySet.add('petrel')
            if(float(columns['black'][counter])) > 0.504526: 
                displaySet.add('bluejay')
        
        
     
        #print displaySet
    testList = list(displaySet)
    randomValuetoDecideFor2ndBest = random.uniform(0, 1)
    randomValuetoDecideFor3rdBest = random.uniform(0, 1)

    for listcounter in range(0,len(testList)):
            #print listcounter
        if(listcounter==1):
            if(randomValuetoDecideFor2ndBest<=0.3):
                break
            else:
                outputFile.write(",")
        if(listcounter==2):
            if(randomValuetoDecideFor3rdBest<=0.1):
                break
            else:
                outputFile.write(",")
                
        outputFile.write(str(testList[listcounter]))
        if(listcounter==2):
            break
        #if(listcounter<len(testList)-1):
        #outputFile.write(",")
        #displaySet.add('\n') 
    outputFile.write('\n')
outputFile.close()      